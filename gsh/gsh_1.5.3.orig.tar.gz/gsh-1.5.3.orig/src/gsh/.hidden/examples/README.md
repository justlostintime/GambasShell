# Examples of plugin scripts for gsh

These scripts are example of how to
create integrated plugins or scripts
for use in the gsh environment
