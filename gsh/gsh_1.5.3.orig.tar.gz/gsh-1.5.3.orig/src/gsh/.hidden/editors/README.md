# Supported text editors
The entries in this directory are the profiles
for each of the text editors supported by
the gsh project

# Currently Supported Editors
  nano
  vim
  kwrite

# Setting the current editor
to set the editor used by gsh assign the value to
the $editor system variable

## The default editor
$editor="nano"